/**
 * This file is specified for power kernel 
 * which access shared memory.
**/


#include<def.h>
#include<cublas.h>

/** 
 * Holds vector size
**/
#define VECT_SIZE 10000000
#define BLOCK_SIZE 512

/**
 * conditional variable
**/
int sigFlag = 1;

/**
 * Holds total time taken to launch the kernel
 * and totak bandwidth of shared memory
**/
float elapsedTimes, bandWidths;

/**
 * Holds start & end time 
**/
cudaEvent_t start,stop;

/**
 * Holds cuda APIs return value
**/
cudaError_t err = cudaSuccess;
   

/**
 * Holds total byte transfer
**/     
double bytes = 2 * sizeof(float) * VECT_SIZE;

/**
* Handle error 
**/
void HANDLE_ERROR(cudaError_t call)
{
        cudaError_t ret = call;
        //printf("RETURN FROM THE CUDA CALL:%d\t:",ret);                                        
        switch(ret)
        {
                case cudaSuccess:
                //              printf("Success\n");                    
                                break;
              case cudaErrorInvalidValue:                             
                                {
                                printf("ERROR: InvalidValue:%i.\n",__LINE__);
                                exit(-1);
                                break;  
                                }                       
                case cudaErrorInvalidDevicePointer:                     
                                {
                                printf("ERROR:Invalid Device pointeri:%i.\n",__LINE__);
                                exit(-1);
                                break;
                                }                       
                case cudaErrorInvalidMemcpyDirection:                   
                                {
                                printf("ERROR:Invalid memcpy direction:%i.\n",__LINE__);        
                                exit(-1);
                                break;
                                }                  
                default:
                        {
                                printf(" ERROR at line :%i.%d' ' %s\n",__LINE__,ret,cudaGetErrorString(ret));
                                exit(-1);
                                break;
                        }
        }
}
