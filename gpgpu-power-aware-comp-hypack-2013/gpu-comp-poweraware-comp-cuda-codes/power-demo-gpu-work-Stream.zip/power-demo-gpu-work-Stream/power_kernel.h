


#include<def.h>
#include<cublas.h>

#define ERRORFILE "error.txt"
#define MAJOR 0
#define MINOR 1
#define GPU_UTILIZATION   0
char* getGPUDevName(int GPUDevId);
#define NTIMES 100 
int printResultsReadable(float times[][NTIMES], long int ,FILE *); 
#define MEMORY_UTILIZATION   1
#define LENGTH 256
int sigFlag = 1;
int counterFlag = 1;
        
/**
 * Function prototypes
**/
int runStream(const int iNumThreadsPerBlock, long int , int ,int , FILE *);
int print_error(char *msg,int nodeNum, int devNum , char *benchName);

/* get Stream Info : start*/
# ifndef MIN
# define MIN(x,y) ((x)<(y)?(x):(y))
# endif
# ifndef MAX
# define MAX(x,y) ((x)>(y)?(x):(y))
# endif




