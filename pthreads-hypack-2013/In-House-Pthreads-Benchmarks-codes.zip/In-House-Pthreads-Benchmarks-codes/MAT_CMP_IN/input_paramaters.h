#define BENCHMARK mat_cmp_in
#define CLASS 'A'
#define THREADS 4 
#define COMPILETIME "23 Fri Sep 2011 18:35:33"
#define CC "gcc"
#define CFLAGS "-O3 "
#define CLINK "$(CC)"
#define CLINKFLAGS "-O3 -lpthread -lm "
#define C_LIB "-lpthread -lm"
#define C_INC "(none)"
