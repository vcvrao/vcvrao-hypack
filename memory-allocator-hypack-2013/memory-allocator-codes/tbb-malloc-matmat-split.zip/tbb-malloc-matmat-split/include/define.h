/* All Global variable define here */

#ifndef _SYSHEADER_H
//  #define _SYSHEADER_H 1
  #include <sys/types.h>
#endif

#ifndef _DEFINE_H
#define _DEFINE_H 1


using namespace std;

extern size_t nrows, ncols;
extern float **ma, **mb, **mc,**ms;

#endif

