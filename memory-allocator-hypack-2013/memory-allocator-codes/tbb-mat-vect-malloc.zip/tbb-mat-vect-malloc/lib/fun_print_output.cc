

#include"../include/headerfiles.h"
#include"../include/proto.h"

void print_output(int size,int numThreads, double t_parallel)             // print result of the program
{
  printf("\n");
  printf("\n Size = %d",nrows);
  printf(" \n numThreads = %d",numThreads);                      
  printf(" \nExecution Time = %g\n",t_parallel);

}
