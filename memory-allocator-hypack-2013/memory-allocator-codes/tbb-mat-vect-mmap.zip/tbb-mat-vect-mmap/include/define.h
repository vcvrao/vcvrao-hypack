

#define MAP_RDONLY   1                     
#define MAP_RDWR     2

