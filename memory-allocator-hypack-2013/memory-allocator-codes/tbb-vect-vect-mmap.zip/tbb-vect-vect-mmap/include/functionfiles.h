

#include"../lib/fun_par_vector_vector_multiply.cc"                 
#include"../lib/fun_mmap_vec_mem_allocation.cc"
#include"../lib/fun_mmap_vector_input.cc"                               // include files which contains function definitions
#include"../lib/fun_memoryfree.cc"
#include"../lib/fun_print_output.cc"

