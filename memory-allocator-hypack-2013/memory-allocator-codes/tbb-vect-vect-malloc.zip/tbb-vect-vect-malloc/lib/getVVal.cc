

#include"../include/headerfiles.h"

float
getVVal (const float *buf, int i,int vsize)                 // get value from vector
{
  size_t id = i;                                      
  return buf[id];
}


