

#include"../lib/fun_par_vector_vector_multiply.cc"
#include"../lib/fun_vec_memory_allocation.cc"
#include"../lib/fun_vector_input.cc"                       // include all .cc file containing function definitions
#include"../lib/fun_memoryfree.cc"
#include"../lib/fun_print_output.cc"
