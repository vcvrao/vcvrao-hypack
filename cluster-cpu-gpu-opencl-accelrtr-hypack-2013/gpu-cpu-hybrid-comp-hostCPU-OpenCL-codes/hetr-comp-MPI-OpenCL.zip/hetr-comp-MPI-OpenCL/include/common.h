/*#*****************************************************************************************
#
#                          C-DAC Tech Workshop : HEMPA-2011
#                             Oct 17 - 21, 2011
#
#  Created         : Aug 2011 
#
#  Email           : betatest@cdac.in        
#****************************************************************************************/

/* including header files that are commonly used */
#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<cstring>
#include<stdlib.h>
#include<math.h>
#include<cstring>
#include<unistd.h>
using namespace std;


