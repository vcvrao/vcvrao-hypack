/*****************************************************************************************

                          C-DAC Tech Workshop : HEMPA-2011
                             Oct 17 - 21, 2011
                               

Descritption    : MPI-Opencl implementation of parallel prefix sum of an array elements.
		  Prefix sum operation is done independantly on each array.
		  "ARRAY_LENGTH" is a preprocessor directive which set input array length.
		  Change its value according to  user requirement.

		  Process 0 take the "ARRAY_LENGTH" values and generate input array elements
		  randomly. Then process 0 distributes the arrays to all other processes for 
		  processing.

		  Other process perform prefix sum of each element of received input array
		  and send the output array elements back to process 0.
Input           : Array , filled with random values.

Output          : Prefix sum values of each array element.

Created         : Aug 2011 

Email           : betatest@cdac.in        
*****************************************************************************************/

 /*........Standard Includes........*/
 #include<mpiOcl.h>   
 
 // define relative kernel path with respective package bin dir so that 
 // at the time of executable running , the kernel can be found at src dir. 
 #define KERNEL_SOURCE_PATH      "./PrefixSum_kernel.cl"

// @brief       Subroutine to fill input array with random input value.
// @param[out]  hInArray Input array, to be filled with initial random values.
// @param[in]   width   Length of input vector.
// @return      On successful execution this subroutine return void.
void fillInArray(cl_int *hInArray, size_t length)
 {
        for(size_t count=0; count< length; count++)
                hInArray[count] = rand()%10;
 }

//----------------------------------------------------------------------
//int main(int argc, char* argv[])

void openCLPrefixSum(cl_int *hInArray, cl_int *hOutArray, size_t length, char *deviceName, int deviceNameLen, int myProcRank)
 {
	
  exeEnvParams exeEnvParamList;
  cl_int status = CL_SUCCESS;
  
  exeEnvParamList.maxNumOfPlatforms = exeEnvParamList.maxNumOfDevices =  MAX_NUM_OF_PLATFORM_AND_DEVICE_ON_EACH_NODE;
  exeEnvParamList.deviceType = CL_DEVICE_TYPE_ALL;
  exeEnvParamList.myProcID = myProcRank;
  exeEnvParamList.kernelBuildSpec = BUILD_USER_DEF_KERNEL;
  strcpy(exeEnvParamList.pathToSrc,KERNEL_SOURCE_PATH);

  //cout<<"\n---------------------------------------------------\n";
  setExeEnv(&exeEnvParamList);
  // cout<<"\n---------------------------------------------------\n";

  cl_device_id attachedDevWithQueue;
  status = clGetCommandQueueInfo( exeEnvParamList.queue, CL_QUEUE_DEVICE, sizeof(cl_device_id),&attachedDevWithQueue,NULL);

  // get device specific information
  cl_device_type attachedDevTypeWithQueue;
  status = clGetDeviceInfo(attachedDevWithQueue,CL_DEVICE_NAME,sizeof(char) * deviceNameLen,deviceName,NULL);

  // create kernel handle
  cl_kernel prefixSum_kernel;
  prefixSum_kernel = clCreateKernel( exeEnvParamList.hProgram, "prefixSum_kernel", &status);
  STATUSCHKMSG("kernel handle");

  //create input array
  cl_mem dInArray = clCreateBuffer(exeEnvParamList.context,CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, length * sizeof(cl_int), (void*)hInArray, &status);
  STATUSCHKMSG("memory allocation ");

  //create output buffer
  cl_mem dOutArray = clCreateBuffer(exeEnvParamList.context, CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR, length * sizeof(cl_int),(void*)hOutArray, &status);
  STATUSCHKMSG("o/p memory allocation");

  //create space for row and col argument 
  cl_int hLength = length;
  cl_mem dLength = clCreateBuffer(exeEnvParamList.context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, sizeof(cl_int),(void*)&hLength, &status);
  STATUSCHKMSG("scaler memory setting");

  //create kernel argument
  //the input array
  status  = clSetKernelArg(prefixSum_kernel,0,sizeof(cl_mem), (void*) &dInArray);
  STATUSCHKMSG("in arg setting");
  //output array
  status = clSetKernelArg(prefixSum_kernel, 1, sizeof(cl_mem), (void*) &dOutArray);
  STATUSCHKMSG("out arg set");
  // scalar value to be multiplied
  status  = clSetKernelArg(prefixSum_kernel,2, sizeof(cl_mem), (void*) &dLength);
  STATUSCHKMSG("scalar value argument");

  // enqueue a kernel run call
  size_t globalThreads[] = { NUMTHREAD };       // number of global items in work dimension 
  size_t localThreads[] = { GROUP_SIZE }; 	// number of work item per group
  status = clEnqueueNDRangeKernel( exeEnvParamList.queue,prefixSum_kernel,1, NULL, globalThreads, localThreads,0,NULL,NULL);
  STATUSCHKMSG("kernel enqueue");

  status = clFinish(exeEnvParamList.queue);
  STATUSCHKMSG("clFinish");

  cl_event events[1];
  // read output result
  status = clEnqueueReadBuffer( exeEnvParamList.queue, dOutArray, CL_TRUE, 0, length * sizeof(cl_int),hOutArray, 0, NULL, &events[0]);
  STATUSCHKMSG("read output");
 // wait for read buffer to complete the read of output produce by kernel
  status = clWaitForEvents(1, &events[0]);
  STATUSCHKMSG("read event not completed");

  clReleaseEvent(events[0]);

  clReleaseKernel(prefixSum_kernel);
  clReleaseProgram(exeEnvParamList.hProgram);
  clReleaseCommandQueue(exeEnvParamList.queue);
  clReleaseContext(exeEnvParamList.context);
 }//end of open_cl_routine 

// please modify "ARRAY_LENGTH" as per user requirement. "ARRAY_LENGTH" specify the input array length,
// on which parallel prefix sum operation operation will be performed.
#define ARRAY_LENGTH   1000


  int main(int argc,char *argv[]) 
   {
    int root = 0,myrank,numprocs,source,dest,iproc;
    int destTag,sourceTag;
    MPI::Status status;
     
    int hInArrayLen = ARRAY_LENGTH;
    int *hInArray = new int[hInArrayLen];
    int *hOutArray = new int[hInArrayLen];
    char procName[BUFFER_SIZE];
    int procNameLen = BUFFER_SIZE;
	char deviceName[BUFFER_SIZE];
    char deviceNameLen = BUFFER_SIZE;

     /*.......MPI Intialization........*/
   
     MPI::Init(argc,argv);
     numprocs = MPI::COMM_WORLD.Get_size();
     myrank = MPI::COMM_WORLD.Get_rank();

     if(myrank == 0){
        for(iproc = 1 ;iproc < numprocs ; iproc++){
           dest = iproc;
           destTag = 0;
	   fillInArray((cl_int*) hInArray, (size_t)hInArrayLen);
	   cout<<"\n Input array to calculate prefix sum value on : process "<<dest<<"\n";
     	   for(size_t count=0; count < 10; count++){
              cout<<" "<<hInArray[ count ];
	   }
           cout<<"\n";
 	   MPI::COMM_WORLD.Send(hInArray,hInArrayLen,MPI_INT,dest,destTag);
        }                   /* End of for loop */  
        for(iproc = 1 ;iproc < numprocs ; iproc++){
           dest = iproc;
           destTag = 0;
	   MPI::COMM_WORLD.Recv(procName,BUFFER_SIZE,MPI::CHAR,dest,destTag);
	   MPI::COMM_WORLD.Recv(deviceName, BUFFER_SIZE, MPI::CHAR,dest,destTag);
	   MPI::COMM_WORLD.Recv(hOutArray, hInArrayLen, MPI::INT, dest, destTag);
	
	   cout<<"\n Processor Name : "<<procName<<"\n Device Name : "<<deviceName<<"\n Output prefix sum value : process "<<dest<<"\n";
     	   for(size_t count=0; count < 10; count++){
              cout<<" "<<hOutArray[ count ];
	   }
           cout<<"\n";
	}
     }                     /* End of if Block*/
    else{
        source =  root;
        sourceTag = 0;
        MPI::COMM_WORLD.Recv(hInArray, hInArrayLen,MPI::INT,source,sourceTag);
        openCLPrefixSum((cl_int*)hInArray, (cl_int*) hOutArray,(size_t) hInArrayLen, deviceName, deviceNameLen, myrank);
        MPI_Get_processor_name(procName, &procNameLen);
        MPI::COMM_WORLD.Send(procName, BUFFER_SIZE,MPI::CHAR,source,sourceTag);
        MPI::COMM_WORLD.Send(deviceName, BUFFER_SIZE,MPI::CHAR,source,sourceTag);
        MPI::COMM_WORLD.Send(hOutArray, hInArrayLen,MPI::INT,source,sourceTag);


    }                    /*end of else block*/
  
       /* ...... Finalizing MPI ....*/
  
          MPI::Finalize();
          return 0;
      }                    /* End of main...*/


