#include"../include/headerfiles.h"

size_t getVID (int i,int nrows)                          // get vector location
{
  assert (i >= 0 && i < nrows);
  return i;
}

