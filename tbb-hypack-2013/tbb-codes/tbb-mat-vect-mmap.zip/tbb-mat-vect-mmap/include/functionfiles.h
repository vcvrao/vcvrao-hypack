

#include"../lib/fun_par_matrix_vector_multiply.cc"                 
#include"../lib/fun_mmap_matvec_mem_allocation.cc"
#include"../lib/fun_mmap_matrix_input.cc"
#include"../lib/fun_mmap_vector_input.cc"                               // include files which contains function definitions
#include"../lib/fun_memoryfree.cc"
#include"../lib/fun_print_output.cc"

