
#include"../include/headerfiles.h"

void
setVVal (float *buf, int i, float val ,int nrows)             // set value in vector
{
  size_t id = i ;
  buf[id] = val;
}

