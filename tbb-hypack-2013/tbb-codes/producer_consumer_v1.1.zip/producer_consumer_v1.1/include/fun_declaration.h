

void producer(int,int);
void consumer(int,int);
